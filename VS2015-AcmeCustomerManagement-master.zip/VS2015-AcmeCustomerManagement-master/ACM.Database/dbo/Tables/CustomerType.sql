﻿CREATE TABLE [dbo].[CustomerType] (
    [CustomerTypeId] INT           NOT NULL IDENTITY,
    [TypeName]    NVARCHAR (50) NULL,
    PRIMARY KEY CLUSTERED ([CustomerTypeId] ASC)
);

