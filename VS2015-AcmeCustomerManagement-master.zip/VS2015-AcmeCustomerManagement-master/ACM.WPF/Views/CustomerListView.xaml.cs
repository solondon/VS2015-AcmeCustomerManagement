﻿using System.Windows.Controls;

namespace ACM.WPF.Views
{
    /// <summary>
    /// Interaction logic for CustomerListView.xaml
    /// </summary>
    public partial class CustomerListView : Page
    {
        public CustomerListView()
        {
            InitializeComponent();
        }
    }
}
